export default {}

type InitOption = {
    [key:string]: string
}