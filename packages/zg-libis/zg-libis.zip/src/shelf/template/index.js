import get from './get'
import parse from './parse/index'
import load from './load'

export default {
    get:get,
    parse:parse,
    load:load
}
